package com.simon.navigation_switcher;
interface INavigationService {
 int getMode();
 boolean setMode(int mode);
 boolean toggle();
}