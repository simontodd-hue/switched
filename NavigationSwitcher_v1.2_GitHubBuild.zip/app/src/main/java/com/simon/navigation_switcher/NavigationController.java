package com.simon.navigation_switcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.content.pm.PackageManager;
import rikka.shizuku.Shizuku;

public final class NavigationController {
 private static final int REQUEST_CODE=1001;
 private static INavigationService service;
 private NavigationController(){}
 public static boolean available(){return Shizuku.pingBinder();}
 public static boolean permission(){return available() && Shizuku.checkSelfPermission()==PackageManager.PERMISSION_GRANTED;}
 public static void request(Context c){if(available()&&!permission())Shizuku.requestPermission(REQUEST_CODE);}
 private static final Shizuku.UserServiceArgs ARGS=new Shizuku.UserServiceArgs(
  new ComponentName("com.simon.navigation_switcher","com.simon.navigation_switcher.NavigationUserService"))
  .daemon(false).version(2).tag("navigation");
 private static final ServiceConnection CONN=new ServiceConnection(){
  public void onServiceConnected(ComponentName n,IBinder b){service=INavigationService.Stub.asInterface(b);}
  public void onServiceDisconnected(ComponentName n){service=null;}
 };
 public static void connect(){
  if(permission())try{Shizuku.bindUserService(ARGS,CONN);}catch(Exception ignored){}
 }
 public static void disconnect(){try{Shizuku.unbindUserService(ARGS,CONN,true);}catch(Exception ignored){} service=null;}
 public static int mode(){
  try{connect(); return service==null?-1:service.getMode();}catch(RemoteException e){return -1;}
 }
 public static boolean set(int m){
  try{connect();return service!=null&&service.setMode(m);}catch(RemoteException e){return false;}
 }
 public static boolean toggle(){
  try{connect();return service!=null&&service.toggle();}catch(RemoteException e){return false;}
 }
}