package com.simon.navigation_switcher;

import android.os.RemoteException;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class NavigationUserService extends INavigationService.Stub {
 private int run(String... args) throws Exception {
  Process p=new ProcessBuilder(args).redirectErrorStream(true).start();
  p.waitFor(); return p.exitValue();
 }
 private String read(String... args) throws Exception {
  Process p=new ProcessBuilder(args).redirectErrorStream(true).start();
  BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()));
  String s=r.readLine(); p.waitFor(); return s==null?"":s.trim();
 }
 private int current() throws Exception {
  try { return Integer.parseInt(read("settings","get","secure","navigation_mode")); }
  catch(Exception e){ return -1; }
 }
 @Override public int getMode() throws RemoteException {
  try{return current();}catch(Exception e){return -1;}
 }
 @Override public boolean setMode(int mode) throws RemoteException {
  if(mode!=0 && mode!=2)return false;
  try{return run("settings","put","secure","navigation_mode",String.valueOf(mode))==0;}
  catch(Exception e){return false;}
 }
 @Override public boolean toggle() throws RemoteException {
  int m=getMode();
  return m==0?setMode(2):m==2&&setMode(0);
 }
 @Override public void destroy(){System.exit(0);}
}