package com.simon.navigation_switcher

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {
 private lateinit var status:TextView
 private lateinit var current:TextView
 private val listener=Shizuku.OnRequestPermissionResultListener{_,_->refresh()}
 override fun onCreate(b:Bundle?){
  super.onCreate(b);setContentView(R.layout.activity_main)
  status=findViewById(R.id.status);current=findViewById(R.id.currentMode)
  Shizuku.addRequestPermissionResultListener(listener)
  findViewById<Button>(R.id.gestureButton).setOnClickListener{runSet(2)}
  findViewById<Button>(R.id.buttonsButton).setOnClickListener{runSet(0)}
  findViewById<Button>(R.id.toggleButton).setOnClickListener{runToggle()}
  findViewById<Button>(R.id.shizukuButton).setOnClickListener{
   try{startActivity(Intent("moe.shizuku.manager.action.MAIN_SETTINGS"))}catch(_:Exception){
    startActivity(Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://shizuku.rikka.app/")))
   }
  }
  refresh()
 }
 override fun onResume(){super.onResume();refresh()}
 private fun access():Boolean{
  if(!NavigationController.available()){status.text="Shizuku: not running";return false}
  if(!NavigationController.permission()){NavigationController.request(this);status.text="Shizuku: permission required";return false}
  return true
 }
 private fun runSet(m:Int){if(!access())return;Thread{NavigationController.set(m);runOnUiThread{refresh()}}.start()}
 private fun runToggle(){if(!access())return;Thread{NavigationController.toggle();runOnUiThread{refresh()}}.start()}
 private fun refresh(){
  status.text=when{
   !NavigationController.available()->"Shizuku: not running"
   !NavigationController.permission()->"Shizuku: permission required"
   else->"Shizuku: connected"
  }
  Thread{
   val m=NavigationController.mode()
   runOnUiThread{current.text=when(m){0->"Current mode: 3-button navigation";2->"Current mode: Gesture navigation";else->"Current mode: Unknown"}}
  }.start()
 }
 override fun onDestroy(){Shizuku.removeRequestPermissionResultListener(listener);NavigationController.disconnect();super.onDestroy()}
}