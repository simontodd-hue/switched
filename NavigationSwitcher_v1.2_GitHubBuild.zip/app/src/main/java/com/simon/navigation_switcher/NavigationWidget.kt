package com.simon.navigation_switcher

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import kotlin.concurrent.thread

class NavigationWidget:AppWidgetProvider(){
 companion object{
  private const val TOGGLE="com.simon.navigation_switcher.TOGGLE"
  fun updateAll(c:Context){
   val m=AppWidgetManager.getInstance(c);val ids=m.getAppWidgetIds(ComponentName(c,NavigationWidget::class.java))
   ids.forEach{updateOne(c,m,it)}
  }
  private fun updateOne(c:Context,m:AppWidgetManager,id:Int){
   val v=RemoteViews(c.packageName,R.layout.navigation_widget)
   val p=PendingIntent.getBroadcast(c,0,Intent(c,NavigationWidget::class.java).setAction(TOGGLE),
    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
   v.setOnClickPendingIntent(R.id.widgetRoot,p);v.setTextViewText(R.id.widgetMode,"Checking…");m.updateAppWidget(id,v)
   thread{
    val label=when(NavigationController.mode()){0->"BUTTONS";2->"GESTURES";else->"NO ACCESS"}
    v.setTextViewText(R.id.widgetMode,label);m.updateAppWidget(id,v)
   }
  }
 }
 override fun onUpdate(c:Context,m:AppWidgetManager,ids:IntArray){ids.forEach{updateOne(c,m,it)}}
 override fun onReceive(c:Context,i:Intent){
  super.onReceive(c,i)
  if(TOGGLE==i.action)thread{NavigationController.toggle();updateAll(c)}
 }
}