plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace="com.simon.navigation_switcher"
    compileSdk=36
    defaultConfig {
        applicationId="com.simon.navigation_switcher"
        minSdk=24
        targetSdk=36
        versionCode=2
        versionName="1.1"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.13.0")
    implementation("dev.rikka.shizuku:api:13.1.5")
}
