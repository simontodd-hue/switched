package com.simon.navigation_switcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.RemoteException;

import rikka.shizuku.Shizuku;

/**
 * Handles the asynchronous Shizuku UserService connection.
 */
public final class NavigationController {

    private static final int REQUEST_CODE = 1001;

    private static final Object LOCK = new Object();
    private static INavigationService service;
    private static boolean binding;

    private static final Shizuku.UserServiceArgs ARGS =
            new Shizuku.UserServiceArgs(
                    new ComponentName(
                            "com.simon.navigation_switcher",
                            "com.simon.navigation_switcher.NavigationUserService"))
                    .daemon(false)
                    .version(3)
                    .tag("navigation");

    private NavigationController() {
    }

    public interface ModeCallback {
        void onResult(int mode);
    }

    public interface BooleanCallback {
        void onResult(boolean success);
    }

    public static boolean available() {
        return Shizuku.pingBinder();
    }

    public static boolean permission() {
        return available()
                && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
    }

    public static void request(Context context) {
        if (available() && !permission()) {
            Shizuku.requestPermission(REQUEST_CODE);
        }
    }

    private static void ensureConnected(final Runnable operation) {
        synchronized (LOCK) {
            if (service != null && service.asBinder().isBinderAlive()) {
                operation.run();
                return;
            }

            if (binding) {
                // Another request is already binding. It will be picked up by
                // the connection callback through the pending queue below.
                pending.add(operation);
                return;
            }

            binding = true;
            pending.add(operation);
        }

        try {
            Shizuku.bindUserService(ARGS, CONN);
        } catch (Throwable e) {
            synchronized (LOCK) {
                binding = false;
                pending.clear();
            }
        }
    }

    private static final java.util.ArrayList<Runnable> pending = new java.util.ArrayList<>();

    private static final ServiceConnection CONN = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            java.util.ArrayList<Runnable> operations;
            synchronized (LOCK) {
                service = INavigationService.Stub.asInterface(binder);
                binding = false;
                operations = new java.util.ArrayList<>(pending);
                pending.clear();
            }
            for (Runnable operation : operations) {
                operation.run();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            synchronized (LOCK) {
                service = null;
                binding = false;
            }
        }
    };

    public static void mode(final ModeCallback callback) {
        if (!permission()) {
            callback.onResult(-1);
            return;
        }

        ensureConnected(() -> {
            int result = -1;
            try {
                synchronized (LOCK) {
                    if (service != null) {
                        result = service.getMode();
                    }
                }
            } catch (RemoteException ignored) {
            }
            final int mode = result;
            callback.onResult(mode);
        });
    }

    public static void set(final int mode, final BooleanCallback callback) {
        if (!permission()) {
            callback.onResult(false);
            return;
        }

        ensureConnected(() -> {
            boolean result = false;
            try {
                synchronized (LOCK) {
                    if (service != null) {
                        result = service.setMode(mode);
                    }
                }
            } catch (RemoteException ignored) {
            }
            callback.onResult(result);
        });
    }

    public static void toggle(final BooleanCallback callback) {
        if (!permission()) {
            callback.onResult(false);
            return;
        }

        ensureConnected(() -> {
            boolean result = false;
            try {
                synchronized (LOCK) {
                    if (service != null) {
                        result = service.toggle();
                    }
                }
            } catch (RemoteException ignored) {
            }
            callback.onResult(result);
        });
    }

    public static void disconnect() {
        try {
            Shizuku.unbindUserService(ARGS, CONN, true);
        } catch (Throwable ignored) {
        }
        synchronized (LOCK) {
            service = null;
            binding = false;
            pending.clear();
        }
    }
}
