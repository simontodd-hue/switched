package com.simon.navigation_switcher

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class NavigationWidget : AppWidgetProvider() {
    companion object {
        private const val TOGGLE = "com.simon.navigation_switcher.TOGGLE"

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, NavigationWidget::class.java)
            )
            ids.forEach { updateOne(context, manager, it) }
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.navigation_widget)
            val intent = Intent(context, NavigationWidget::class.java).setAction(TOGGLE)
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                id,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            views.setOnClickPendingIntent(R.id.widgetRoot, pendingIntent)
            views.setTextViewText(R.id.widgetMode, "Checking…")
            manager.updateAppWidget(id, views)

            if (!NavigationController.available() || !NavigationController.permission()) {
                views.setTextViewText(R.id.widgetMode, "NO ACCESS")
                manager.updateAppWidget(id, views)
                return
            }

            NavigationController.mode { mode ->
                val label = when (mode) {
                    0 -> "BUTTONS"
                    2 -> "GESTURES"
                    else -> "NO ACCESS"
                }
                views.setTextViewText(R.id.widgetMode, label)
                manager.updateAppWidget(id, views)
            }
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        appWidgetIds.forEach { updateOne(context, appWidgetManager, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (TOGGLE == intent.action) {
            if (NavigationController.available() && NavigationController.permission()) {
                NavigationController.toggle {
                    updateAll(context)
                }
            } else {
                updateAll(context)
            }
        }
    }
}
