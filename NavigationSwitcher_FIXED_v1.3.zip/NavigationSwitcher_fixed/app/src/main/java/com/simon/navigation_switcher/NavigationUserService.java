package com.simon.navigation_switcher;

import android.os.RemoteException;
import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * Shizuku UserService. This class is instantiated by Shizuku in the shell/root
 * context, not as a normal Android Service.
 */
public class NavigationUserService extends INavigationService.Stub {

    public NavigationUserService() {
    }

    private int run(String... args) throws Exception {
        Process p = new ProcessBuilder(args)
                .redirectErrorStream(true)
                .start();
        p.waitFor();
        return p.exitValue();
    }

    private String read(String... args) throws Exception {
        Process p = new ProcessBuilder(args)
                .redirectErrorStream(true)
                .start();
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String s = r.readLine();
        p.waitFor();
        return s == null ? "" : s.trim();
    }

    private int current() throws Exception {
        String value = read("settings", "get", "secure", "navigation_mode");
        return Integer.parseInt(value);
    }

    @Override
    public int getMode() throws RemoteException {
        try {
            return current();
        } catch (Exception e) {
            return -1;
        }
    }

    @Override
    public boolean setMode(int mode) throws RemoteException {
        if (mode != 0 && mode != 2) {
            return false;
        }
        try {
            return run("settings", "put", "secure", "navigation_mode", String.valueOf(mode)) == 0;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean toggle() throws RemoteException {
        int mode = getMode();
        if (mode == 0) {
            return setMode(2);
        }
        if (mode == 2) {
            return setMode(0);
        }
        return false;
    }

    @Override
    public void destroy() {
        System.exit(0);
    }
}
