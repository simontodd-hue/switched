package com.simon.navigation_switcher;

interface INavigationService {
    void destroy() = 16777114;
    int getMode() = 1;
    boolean setMode(int mode) = 2;
    boolean toggle() = 3;
}
