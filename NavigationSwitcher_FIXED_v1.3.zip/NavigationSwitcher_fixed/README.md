# Navigation Switcher 1.1

Samsung Galaxy S23 Ultra / Android 16 target.

Features:
- Gesture navigation / 3-button navigation
- One-tap toggle widget
- Current mode detection
- Shizuku UserService
- Reconnects when the app resumes
- Widget shows NO ACCESS if Shizuku is unavailable
- UserService version is bumped so Shizuku recreates updated service code
- Explicit Shizuku button
- No INTERNET permission and no analytics

Build in Android Studio or AndroidIDE with Android SDK 36.

Shizuku is required. On Android 11+, Shizuku can be started using the phone's Wireless debugging facility. Shizuku documents that non-root operation requires restarting the service after boot.

The app uses the standard Android navigation_mode values:
0 = 3-button
2 = gesture

Samsung may alter behaviour in future One UI versions; this app is intended for the stated S23 Ultra / Android 16 setup.


## Build directly from your phone with GitHub Actions

1. Create a GitHub repository from your phone.
2. Upload the contents of this project to the repository (not the ZIP itself).
3. Open the repository's **Actions** tab.
4. Select **Build Navigation Switcher APK** and choose **Run workflow**.
5. When it finishes, open the completed workflow run.
6. Download the **NavigationSwitcher-debug** artifact.
7. Extract it and install `app-debug.apk` on the S23 Ultra.

This workflow installs Android SDK 36 and JDK 17 on GitHub's runner, so AndroidIDE is not required.

NOTE: GitHub's web interface may be awkward for uploading a whole project from a phone. If that becomes a problem, use GitHub's mobile/browser upload facility to add the files/folders individually, or use a Git client app on Android.
